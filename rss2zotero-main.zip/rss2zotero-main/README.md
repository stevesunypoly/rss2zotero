# rss2zotero
python script with yaml config to harness rss feeds and upload new hits to zotero group via api
